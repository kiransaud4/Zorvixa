import React from 'react'
import Section from '../Section'

export default function Home() {
  return (
    <>
    <Section/>
    </>
  )
}
