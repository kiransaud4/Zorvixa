import React from 'react'
import Header from '../Header'
import Navbar from '../Navbar'
import Section from '../Section'
import Footer from '../Footer'

export default function Home() {
  return (
    <>
    <Header/>
    <Navbar/>
    <Section/>
    <Footer/>
    </>
  )
}
