import React from 'react'

export default function Ourteam() {
  return (
    <div>Our Team</div>
  )
}
