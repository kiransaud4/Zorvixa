import React from 'react'

export default function Pages() {
  return (
    <div>Pages</div>
  )
}
